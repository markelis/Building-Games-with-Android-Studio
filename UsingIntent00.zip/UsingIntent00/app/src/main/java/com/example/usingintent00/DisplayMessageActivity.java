package com.example.usingintent00;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayMessageActivity extends AppCompatActivity {
    boolean isMale;
    boolean isFemale;
    ImageView avatar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);
        avatar = findViewById(R.id.imageView);
        Intent intent = getIntent();
        String message = "Καλημέρα " + intent.getStringExtra(MainActivity.EXTRA_MESSAGE)+ "!";
        isMale = intent.getBooleanExtra("isMale", false);
        isFemale = intent.getBooleanExtra("isFemale", false);
        TextView textView = findViewById(R.id.textViewDisplay);
        textView.setText(message);
        if(isMale){
            avatar.setImageResource(R.drawable.boy);
        } else if (isFemale) {
            avatar.setImageResource(R.drawable.girl);
        }
    }
}

