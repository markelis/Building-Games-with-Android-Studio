package com.example.activity101;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    public int startCounter = 1;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onStart() {
        super.onStart();
        Button extButton = findViewById(R.id.exit_button);
        extButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("ΕΞΟΔΟΣ");
                builder.setMessage("Η εφαρμογή εκκίνησε " + startCounter + " φορές. Θέλετε σίγουρα να την τερματήσετε;");
                builder.setPositiveButton("ΝΑΙ. ΤΩΡΑ!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }

                });
                builder.setNegativeButton("ΟΧΙ ΤΩΡΑ...", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });
        progressDialog = ProgressDialog.show(this, "Παρακαλώ περιμένετε", "Επεξεργασία δεδομένων...", true);
        final Handler handler = new Handler();
        CountDownTimer t = new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                progressDialog.setMessage("Εναπομείναντα δευτερόλεπτα: : " + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                progressDialog.setMessage("Ολοκληρώθηκε!");
                handler.postDelayed(new Runnable() {
                    public void run() {
                        progressDialog.dismiss();
                    }
                }, 1000);
            }
        }.start();
    }

    public void onPause() {
        super.onPause();
        startCounter += 1;
    }

    public void onResume() {
        super.onResume();
    }

    public void onRestart() {
        super.onRestart();
    }

}